# Global variables
